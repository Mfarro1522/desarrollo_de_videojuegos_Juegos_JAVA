package tiles;

import java.awt.image.BufferedImage;

public class Tile {

	public BufferedImage imagen;
	public boolean colision = false;
}
