module PrimerJuego2D {
	exports tiles;
	exports entidad;
	exports main;
	exports objetos;

	requires java.desktop;
}